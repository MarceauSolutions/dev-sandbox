# GO Tracker

A dead-simple activity tracker. Press GO, it tracks. No questions asked.

## Features
- One-tap start tracking
- Distance, time, pace, speed (top & avg)
- Elevation gain/loss with profile chart
- Route visualization
- Export to GPX (Strava-compatible) or JSON

## Setup Instructions

### Prerequisites
- Node.js 18+ installed
- VS Code with Claude extension (optional but helpful)

### Step 1: Install Expo CLI
```bash
npm install -g expo-cli
```

### Step 2: Navigate to project folder
```bash
cd GoTracker
```

### Step 3: Install dependencies
```bash
npm install
```

### Step 4: Create assets folder and placeholder images
```bash
mkdir assets
```
You'll need to add:
- `assets/icon.png` (1024x1024 app icon)
- `assets/splash.png` (1284x2778 splash screen)
- `assets/adaptive-icon.png` (1024x1024 for Android)

Or just create simple placeholder images for now.

### Step 5: Start the development server
```bash
npx expo start
```

### Step 6: Run on your device
- **iOS**: Scan QR code with Camera app (requires Expo Go from App Store)
- **Android**: Scan QR code with Expo Go app (from Play Store)
- **Simulator**: Press `i` for iOS simulator or `a` for Android emulator

## Building for Production

### iOS (requires Mac + Apple Developer account)
```bash
npx expo build:ios
```

### Android
```bash
npx expo build:android
```

Or use EAS Build (recommended):
```bash
npm install -g eas-cli
eas build --platform all
```

## Project Structure
```
GoTracker/
├── App.js          # Main app component
├── app.json        # Expo configuration
├── package.json    # Dependencies
└── assets/         # Icons and splash screens
```

## Notes
- GPS accuracy depends on device hardware
- Elevation data requires barometric altimeter for best results
- Background tracking works on iOS with proper permissions
- GPX exports can be imported directly to Strava, Garmin Connect, etc.
